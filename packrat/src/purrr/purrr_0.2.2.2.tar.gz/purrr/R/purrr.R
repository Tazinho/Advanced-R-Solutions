#' @keywords internal
#' @useDynLib purrr, .registration = TRUE
"_PACKAGE"
