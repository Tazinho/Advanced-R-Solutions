## plogr 0.1-1 (2016-09-24)

- Remove useless operator overloads.
- Reword description.


# plogr 0.1 (2016-09-24)

- Using a stripped version of plog 1.0-1.
- Works on Linux, OS X, and Windows.
- Log items are printed using.
- New `plog::init_r()` to initialize logging via  `REprintf()`, allows changing the log level and passing the log level as string.
