.onLoad = function(lib, pkg) {
  register_eng_math(names(theorem_abbr), eng_theorem)
  register_eng_math(names(label_names_math2), eng_proof)
}
