library(testthat)
library(sloop)

test_check("sloop")
