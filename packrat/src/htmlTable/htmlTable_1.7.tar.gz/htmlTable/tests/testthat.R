library('testthat')

test_check('htmlTable')
