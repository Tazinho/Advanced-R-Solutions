library(testthat)
library(bench)

test_check("bench")
