
context("boxes")

test_that("boxes works", {

  expect_true(TRUE)

})
