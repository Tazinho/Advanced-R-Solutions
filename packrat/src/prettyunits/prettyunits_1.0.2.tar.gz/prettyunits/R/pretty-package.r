
#' Prettier formatting of quantities
#'
#' @docType package
#' @name prettyunits
#' @importFrom magrittr %>%
NULL

. <- "STFU"
