".onUnload" <- function(libpath) {
	stopImplicitCluster()
}
