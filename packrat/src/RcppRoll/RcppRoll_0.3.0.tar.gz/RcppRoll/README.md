RcppRoll
=====

This package provides windowed-versions of commonly-used mathematical
and statistical functions.

Install me with devtools:

    install_github("kevinushey/RcppRoll")
