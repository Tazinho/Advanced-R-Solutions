/*
**********************************************************************
*   Copyright (C) 2006, International Business Machines
*   Corporation and others.  All Rights Reserved.
**********************************************************************
*/

#ifndef UBRKIMPL_H
#define UBRKIMPL_H

#define U_ICUDATA_BRKITR U_ICUDATA_NAME U_TREE_SEPARATOR_STRING "brkitr"

#endif /*UBRKIMPL_H*/
